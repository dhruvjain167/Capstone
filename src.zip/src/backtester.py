import numpy as np
from config import WINDOW, STEP, DCC_A, DCC_B
from garch_x_model import fit_garch, fit_garch_x
from dcc_model import compute_dcc
from hedge_engine import compute_covariance_matrix, compute_multivariate_hedge, adjust_hedge

def run_backtest(df):

    returns = df.drop(columns=["sentiment_score"])
    sentiment = df["sentiment_score"]

    portfolio_returns = []
    
    for t in range(WINDOW, len(df), STEP):
        
        window = returns.iloc[t-WINDOW:t]
        window_sent = sentiment.iloc[t-WINDOW:t].shift(1).fillna(0)
        
        sigmas_last = []
        std_resids = []
        
        for i, col in enumerate(window.columns):
            
            if col == "NIFTY":
                sigma, resid = fit_garch_x(window[col], window_sent)
            else:
                sigma, resid = fit_garch(window[col])
            
            sigmas_last.append(sigma.iloc[-1])
            std_resids.append(resid)
        
        std_resids = np.column_stack(std_resids)
        
        R_series = compute_dcc(std_resids, DCC_A, DCC_B)
        R_last = R_series[-1]
        
        H_t = compute_covariance_matrix(R_last, sigmas_last)
        
        hedge_vector = compute_multivariate_hedge(H_t)
        hedge_vector = adjust_hedge(hedge_vector, sentiment.iloc[t])
        
        r_t = returns.iloc[t]
        hedge_returns = np.dot(hedge_vector, r_t[1:])
        
        portfolio_r = r_t[0] - hedge_returns
        portfolio_returns.append(portfolio_r)
    
    return np.array(portfolio_returns)