import numpy as np
from arch import arch_model

def fit_garch(series):
    model = arch_model(series, vol="Garch", p=1, q=1)
    res = model.fit(disp="off")
    sigma = res.conditional_volatility
    std_resid = res.resid / sigma
    return sigma, std_resid

def fit_garch_x(series, exog):
    model = arch_model(series, vol="Garch", p=1, q=1, x=exog)
    res = model.fit(disp="off")
    sigma = res.conditional_volatility
    std_resid = res.resid / sigma
    return sigma, std_resid